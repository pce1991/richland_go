﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piece : MonoBehaviour
{
    enum PieceState
    {
        Resting,
        Moving,

    }

    PieceState state;

    Vector3 startPos;
    Vector3 endPos;

    float moveDuration;
    float timeMoveStarted;

    // Start is called before the first frame update
    void Start()
    {
        state = PieceState.Resting;
        moveDuration = 0.18f;
    }

    public void StartMove(Vector3 start, Vector3 end)
    {
        state = PieceState.Moving;

        startPos = start;
        endPos = end;

        timeMoveStarted = Time.time;

        Debug.Log(timeMoveStarted);
    }

    // Update is called once per frame
    void Update()
    {
        if (state == PieceState.Moving)
        {
            float timeElapsed = Time.time - timeMoveStarted;

            float t = timeElapsed / moveDuration;

            if (t > 1.0f)
            {
                state = PieceState.Resting;
            }

            // n = ((1 - t) * a) + (t * b))
            transform.position = Vector3.Lerp(startPos, endPos, t);
        }
        else
        {
            Debug.Log(state);
        }
    }
}
